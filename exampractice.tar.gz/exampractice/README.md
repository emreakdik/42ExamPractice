# 42ExamPractice

```
in progress
```

You will find merged exam subjects in this repository. My aim is to improve exam practice by merging subjects.

Please note that this repository does not contain all subjects for all levels. I will publish the subjects for each level when I start practicing them.

I have noticed that existing exam apps do not allow us to adjust the difficulty level of questions. In the future, I plan to develop a terminal application that will allow us to practice questions according to the levels of the exams.