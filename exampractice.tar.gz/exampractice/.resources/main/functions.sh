#!/bin/bash

function print_subs(){
    folder_path=$1
    folders=
}







